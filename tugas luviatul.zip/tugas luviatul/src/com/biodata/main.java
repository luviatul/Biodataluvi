package com.biodata;

public class main {
    public static void main(String[] args){
        System.out.println("Nama Lengkap    : Luviatul Muayudah");
        System.out.println("Jenis Kelamin   : Perempuan");
        System.out.println("Alamat          : Dsn.Payaman RT.01/Rw.01 Ds.Sukodermo Kec.Purwosari Kab.Pasuruan");
        System.out.println("Jurusan         : Rekayasa Perangkat Lunak");
    }
}
